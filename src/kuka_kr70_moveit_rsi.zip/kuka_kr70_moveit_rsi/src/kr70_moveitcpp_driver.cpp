#include <rclcpp/rclcpp.hpp>
#include <moveit/move_group_interface/move_group_interface.h>
#include <geometry_msgs/msg/pose.h>
#include <tf2_geometry_msgs/tf2_geometry_msgs.h>
#include <tf2/LinearMath/Transform.h>
#include <tf2/LinearMath/Matrix3x3.h>
#include <tf2/LinearMath/Quaternion.h>

// Helper function to print tf2::Transform as translation and SO(3) (rotation matrix and RPY)
void printTransform(const tf2::Transform& tf, const std::string& name)
{
    const tf2::Vector3& t = tf.getOrigin();
    const tf2::Quaternion& q = tf.getRotation();
    double roll, pitch, yaw;
    tf2::Matrix3x3(q).getRPY(roll, pitch, yaw);

    std::cout << name << " translation: [" << t.x() << ", " << t.y() << ", " << t.z() << "]" << std::endl;
    std::cout << name << " quaternion: [" << q.x() << ", " << q.y() << ", " << q.z() << ", " << q.w() << "]" << std::endl;
    std::cout << name << " RPY: [" << roll << ", " << pitch << ", " << yaw << "]" << std::endl;

    // Print the rotation matrix
    tf2::Matrix3x3 m(q);
    std::cout << name << " rotation matrix:" << std::endl;
    for (int i = 0; i < 3; ++i)
        std::cout << "[" << m[i][0] << " " << m[i][1] << " " << m[i][2] << "]" << std::endl;
}


class RelativePoseCommander : public rclcpp::Node
{
public:
  RelativePoseCommander() : Node("kr70_relative_pose_commander")
  {
    subscription_ = this->create_subscription<geometry_msgs::msg::Pose>(
      "relative_pose_cmd", rclcpp::QoS(1).best_effort(),
      std::bind(&RelativePoseCommander::relative_pose_callback, this, std::placeholders::_1));
  }

  void initialize_move_group()
  {
    move_group_ = std::make_shared<moveit::planning_interface::MoveGroupInterface>(
      shared_from_this(), "manipulator");
    
    move_group_->setMaxVelocityScalingFactor(0.1);
    move_group_->setMaxAccelerationScalingFactor(0.1);

    std::vector<std::string> link_names = move_group_->getLinkNames();
    for (const auto& ln : link_names){
        RCLCPP_INFO(this->get_logger(), "Link: %s", ln.c_str());
    }

    // auto param_names = this->list_parameters({}, 10).names;
    // for (const auto& n : param_names)
    //     RCLCPP_INFO(this->get_logger(), "Parameter: %s", n.c_str());

  }
private:
  void relative_pose_callback(const geometry_msgs::msg::Pose::SharedPtr rel_pose_msg)
  {
    // 1. Get current flange pose
    geometry_msgs::msg::PoseStamped curr_flange_pose = move_group_->getCurrentPose("tool0");

    // 2. Convert current and relative pose to tf2::Transform
    tf2::Transform curr_tf, rel_tf;
    tf2::fromMsg(curr_flange_pose.pose, curr_tf);
    tf2::fromMsg(*rel_pose_msg, rel_tf);

    // 3. Compose: next_goal = curr_flange * rel_tf
    tf2::Transform goal_tf = curr_tf * rel_tf;
    geometry_msgs::msg::Pose goal_pose;
    goal_pose.position.x = goal_tf.getOrigin().x();
    goal_pose.position.y = goal_tf.getOrigin().y();
    goal_pose.position.z = goal_tf.getOrigin().z();
    goal_pose.orientation = tf2::toMsg(goal_tf.getRotation());
    
    printTransform(curr_tf, "Current TF");
    printTransform(rel_tf, "Relative TF");

    // 4. Plan and execute
    move_group_->setPoseTarget(goal_pose, "link_6");
    moveit::planning_interface::MoveGroupInterface::Plan plan;
    bool success = (move_group_->plan(plan) == moveit::planning_interface::MoveItErrorCode::SUCCESS);
    if (success)
    {
      RCLCPP_INFO(this->get_logger(), "Relative move planned. Executing...");
      // move_group_->execute(plan);
    }
    else
    {
      RCLCPP_WARN(this->get_logger(), "Planning failed for relative move!");
    }
  }

  std::shared_ptr<moveit::planning_interface::MoveGroupInterface> move_group_;
  rclcpp::Subscription<geometry_msgs::msg::Pose>::SharedPtr subscription_;
};

int main(int argc, char** argv)
{
    rclcpp::init(argc, argv);
    auto node = std::make_shared<RelativePoseCommander>();
    node->initialize_move_group();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}
